# Este arquivo está sendo substituído pelos schemas específicos
# Os schemas foram transferidos para arquivos individuais:
# - dataset.py
# - image.py
# - annotation.py
# - training_session.py
# - model.py
# - inference_result.py 